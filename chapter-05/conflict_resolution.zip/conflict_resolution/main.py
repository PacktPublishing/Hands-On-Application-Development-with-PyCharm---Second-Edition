foo = "baz baz baz"

text = "I'm adding this line"
